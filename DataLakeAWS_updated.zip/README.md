# Project: Data Lake

## About the project

This project is created for a startup called *Sparkify*. Its new music streaming app has grown their user base and song database even more so they want to move their data warehouse to a data lake. Their data resides in S3, in a directory of JSON logs on user activity on the app, as well as a directory with JSON metadata on the songs in their app.

To help *Sparkify*, I was brought to the project. The main project activities included building an ETL pipeline that extracts their data from S3, processes them using Spark, and loads the data back into S3 as a set of dimensional tables. This will allow their analytics team to continue finding insights in what songs their users are listening to.

## Datasets

*Sparkify* provided me with two datasets - Songs and Logs.

Songs dataset includes all the metadata about a song and an artist. Below is an example of one of the JSON files:

**TRAAABD128F429CF47.json**

`{"num_songs": 1, "artist_id": "ARMJAGH1187FB546F3", "artist_latitude": 35.14968, "artist_longitude": -90.04892, "artist_location": "Memphis, TN", "artist_name": "The Box Tops", "song_id": "SOCIWDW12A8C13D406", "title": "Soul Deep", "duration": 148.03546, "year": 1969}`

Logs dataset includes all the data about user activity on the app. Below is an example of one of the JSON files:

**2018-11-01-events.json**

`{"artist":null,"auth":"Logged In","firstName":"Walter","gender":"M","itemInSession":0,"lastName":"Frye","length":null,"level":"free","location":"San Francisco-Oakland-Hayward, CA","method":"GET","page":"Home","registration":1540919166796.0,"sessionId":38,"song":null,"status":200,"ts":1541105830796,"userAgent":"\"Mozilla\/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/36.0.1985.143 Safari\/537.36\"","userId":"39"}`

Both datasets can be found in S3 storage. Below are examples of the filepaths:

**s3://udacity-dend/song_data**
**s3://udacity-dend/log_data**

## Database schema

The schema that I needed to create consists of **one fact table** and **four dimension tables**.

The fact table called *songplays* includes the following columns:

**songplays table**

- songplay_id
- start_time
- userId
- level
- song_id
- artist_id
- sessionId
- location
- userAgent

The dimension tables called *artists*, *songs*, *users*, *time* include the following columns:

**artists table**

- artist_id
- artist_name
- artist_location
- artist_latitude
- artist_longitude

**songs table**

- song_id
- title
- artist_id
- year
- duration

**users table**

- userId
- firstName
- lastName
- gender
- level

**time table**

- start_time
- hour
- day
- week
- month
- year
- weekday

# Project's template files

To implement specific project activities, I was provided with the following files:

1. **etl.py** - for reading data from S3, processing that data using Spark, and writing them back to S3.

2. **dl.cfg**  - for listing my AWS credentials.

3. **README.md**  - for providing discussion on this project.
