from pyspark.sql import SparkSession
import configparser
from datetime import datetime
import os
from pyspark.sql.functions import udf, col
from pyspark.sql.functions import (year, month, dayofmonth,
                                   dayofweek, hour, weekofyear, date_format)
from pyspark.sql.functions import monotonically_increasing_id
from pyspark.sql.functions import (to_timestamp, to_date,
                                   from_unixtime, to_utc_timestamp)
from pyspark.sql.types import TimestampType, DateType

config = configparser.ConfigParser()
config.read('dl.cfg')

os.environ['AWS_ACCESS_KEY_ID'] = config['AWS']['AWS_ACCESS_KEY_ID']
os.environ['AWS_SECRET_ACCESS_KEY'] = config['AWS']['AWS_SECRET_ACCESS_KEY']


# os.environ['AWS_ACCESS_KEY_ID']=config.get('AWS','AWS_ACCESS_KEY_ID')
# os.environ['AWS_SECRET_ACCESS_KEY']=config.get('AWS','AWS_SECRET_ACCESS_KEY')


def create_spark_session():
    """Creates an entry point to Spark with needed packages"""
    spark = SparkSession \
        .builder \
        .config("spark.jars.packages", "org.apache.hadoop:hadoop-aws:2.7.0") \
        .getOrCreate()
    return spark


def process_song_data(spark, input_data, output_data):
    """
    Processes song data by taking all the files from the given filepath;
    creates songs and artists tables;
    writes parquet files in the given locations.
    """

    # get filepath to song data file
    song_data = input_data + 'song_data/*/*/*/*.json'
    # song_data = input_data + 'song_data/*/*.json'

    # read song data file
    song_df = spark.read.json(song_data).dropDuplicates(["song_id"])

    # extract columns to create songs table
    songs_table = song_df.select("song_id", "title", "artist_id",
                                 "year", "duration").distinct()

    # write songs table to parquet files partitioned by year and artist
    songs_table.write.partitionBy("year", "artist_id").mode("overwrite") \
        .parquet(output_data + 'songs/songs_table.parquet')

    # extract columns to create artists table
    artists_table = song_df.select("artist_id", "artist_name", "artist_location",
                                   "artist_latitude", "artist_longitude").distinct()

    # write artists table to parquet files
    artists_table.write.mode("overwrite").parquet(output_data + 'songs/artists_table.parquet')


def process_log_data(spark, input_data, output_data):
    """
    Processes log data by taking all the files from the given filepath;
    creates users, time, and songplays tables;
    writes parquet files in the given locations.
    """

    # get filepath to log data file
    log_data = input_data + 'log_data/*/*/*.json'
    # log_data = input_data + 'log_data/*.csv'

    # read log data file
    log_df = spark.read.json(log_data)
    # log_df = spark.read.option("header", "true").csv(log_data)

    # filter by actions for song plays
    log_df_2 = log_df.filter(log_df.page == "NextSong")

    # extract columns for users table
    users_table = log_df_2.select("userId", "firstName", "lastName", "gender", "level")\
        .distinct().sort("userId")

    # write users table to parquet files
    users_table.write.mode("overwrite").parquet(output_data + 'logs/users_table.parquet')

    # create function to get timestamp from bigint
    get_timestamp = lambda x: to_timestamp(x / 1000)

    # create timestamp column from original timestamp column
    # in the files example, ts is bigint, not timestamp (?)
    # log_df_3 = log_df_2.withColumn("timestamp", get_timestamp(col("ts")))

    # create datetime column from original timestamp column
    # get_datetime = udf(lambda x: to_date(from_unixtime(x)), DateType())

    # create start_time column from ts
    log_df_3 = log_df_2.withColumn("start_time", get_timestamp(col("ts")))

    # creating separate columns to use later for partitions
    log_df_4 = log_df_3.withColumn("hour", hour(to_utc_timestamp("start_time", '+02:00'))) \
        .withColumn("day", dayofmonth("start_time")) \
        .withColumn("week", weekofyear("start_time")) \
        .withColumn("month", month("start_time")) \
        .withColumn("year", year("start_time")) \
        .withColumn("weekday", dayofweek("start_time")).distinct()

    # extract columns to create time table
    time_table = log_df_3.select("start_time") \
        .withColumn("hour", hour("start_time")) \
        .withColumn("day", dayofmonth("start_time")) \
        .withColumn("week", weekofyear("start_time")) \
        .withColumn("month", month("start_time")) \
        .withColumn("year", year("start_time")) \
        .withColumn("weekday", dayofweek("start_time")).distinct()

    # write time table to parquet files partitioned by year and month
    time_table.write.partitionBy("year", "month").mode("overwrite").parquet(output_data + 'logs/time_table.parquet')

    # read in song data to use for songplays table
    song_df = spark.read.json(input_data + 'song_data/*/*/*/*.json')\
        .dropDuplicates(["song_id"])
    # song_df = spark.read.json(input_data + 'song_data/*/*.json')
    # .dropDuplicates(["song_id"])

    # extract columns from joined song and log datasets to create songplays table
    songplays_table = log_df_4.join(song_df,
                                    (log_df_4.song == song_df.title) & (log_df_4.artist == song_df.artist_name),
                                    "inner") \
        .select("start_time", log_df_4.year, log_df_4.month, "userId", "level", "song_id", "artist_id", "sessionId",
                "location", "userAgent") \
        .withColumn("songplay_id", monotonically_increasing_id())

    # write songplays table to parquet files partitioned by year and month
    songplays_table.write.partitionBy("year", "month").mode("overwrite") \
        .parquet(output_data + 'songplays/songplays_table.parquet')


def main():
    """Gets spark object from spark session; states input/output bucket; processes song and log data"""
    spark = create_spark_session()
    input_data = "s3a://udacity-dend/"
    # input_data = "s3://test-pizza/input/"
    output_data = "s3a://udacity-dend/"
    # output_data = "s3://test-pizza/output/"

    process_song_data(spark, input_data, output_data)
    process_log_data(spark, input_data, output_data)

    spark.stop()


if __name__ == "__main__":
    main()
